extends Area2D
var entrou = false
signal jaula_aberta
var chave_pegada = false
var perto_jaula = false

func _on_body_entered(body: CharacterBody2D):
	entrou = true
func _physics_process(delta):
	if entrou and Input.is_action_just_pressed("ui_down"):
		visible = false
		chave_pegada = true
		set_collision_layer_value(4,false)
		print("chave coletada")
		$CollisionShape2D.queue_free()
		entrou = false
		
func _on_prision_body_entered(body: PhysicsBody2D):
	perto_jaula = true 
	print("perto da jaula")
	
func _process(delta:):
	if chave_pegada and perto_jaula and Input.is_action_just_pressed("ui_up"):
		emit_signal("jaula_aberta")
		print("jaula foi abrida")
		
