extends Area2D
var entrou = false
func _on_body_entered(body: CharacterBody2D):
	entrou = true

func _physics_process(delta):
	if entrou and Input.is_action_just_pressed("ui_down"):
		visible = false
		set_collision_layer_value(4,false)
		print("chave coletada")
		$SoundKey.play()

func _on_sound_key_finished():
	queue_free()
