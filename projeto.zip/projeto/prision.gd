extends Area2D


func _on_chave_jaula_aberta():
	queue_free()
