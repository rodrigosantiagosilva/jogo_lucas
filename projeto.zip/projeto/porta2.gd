extends Area2D

var entrou = false

func _on_body_entered(body):
	entrou = true
func _on_body_exited(body):
	entrou =false
func _physics_process(delta):
	if entrou and Input.is_action_just_pressed("ui_up"):
		$anima_porta1.play("abreu")
func _on_anima_porta_1_animation_finished(anim_name):
	get_tree().change_scene_to_file("res://mundo1.tscn")
